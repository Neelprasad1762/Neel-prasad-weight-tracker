NEEL PRASAD WEIGHT-LOSS TRACKER

Files:
- index.html: the mobile-friendly tracker
- manifest.webmanifest: Home Screen app metadata
- sw.js: basic offline caching for a hosted HTTPS version

Important:
This is a website bundle, not a hosted website. To use “Add to Home Screen” as a standalone app on iPhone, upload these files to an HTTPS host (for example, GitHub Pages or another static web host), then open the hosted URL in Safari > Share > Add to Home Screen.

Tracker data is saved locally in the browser on the device. Export regularly if you want a backup. It does not sync to other devices.
